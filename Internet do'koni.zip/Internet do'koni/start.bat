@echo off
cd /d "%~dp0"
echo O'zbek Bozor serveri ishga tushmoqda...
echo Brauzerda oching: http://localhost:3000
npm.cmd start
pause
