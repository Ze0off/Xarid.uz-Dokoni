Mahsulot rasmlarini shu papkaga qo'ying.

Kerakli rasm nomlari:

product1.jpg - Redmi note 12
product2.jpg - Noutbuk
product3.jpg - Quloqchin
product4.jpg - Iphone 17 pro max

Rasmlar bo'lmasa ham sayt ishlaydi, faqat rasm joyi bo'sh chiqadi.

Sayt ikonkasini qo'yish uchun:
icon.png - brauzer tabidagi sayt ikonka rasmi
