let products = [
  { id: 1, name: 'Redmi note 12', price: 3500000, image: 'images/Redni-Note12.jpeg', description: 'Redmi note 12 kundalik foydalanish uchun qulay smartfon.' },
  { id: 2, name: 'ASUS Vivobook Noutbuk', price: 6500000, image: 'images/Asus-Vivobook.png', description: 'ASUS Vivobook o\'qish va ish uchun mos noutbuk.' },
  { id: 3, name: 'Quloqchin', price: 350000, image: 'images/Quloqchin.jpg', description: 'Quloqchin musiqa tinglash va qo\'ng\'iroqlar uchun qulay.' },
  { id: 4, name: 'Iphone 17 pro max', price: 22500000, image: 'images/Ayfon17.jpg', description: 'Iphone 17 pro max premium smartfon.' }
];
let cart = JSON.parse(localStorage.getItem('cart')) || [];

const $ = id => document.getElementById(id);

function money(price) {
  return price.toLocaleString('uz-UZ') + " so'm";
}

function save() {
  localStorage.setItem('cart', JSON.stringify(cart));
  showCart();
}

async function loadProducts() {
  try {
    const res = await fetch('/products');
    products = await res.json();
  } catch (error) {
    console.log('Server ishlamasa ham mahsulotlar ko\'rsatiladi');
  }

  $('products').innerHTML = products.map(product => `
    <div class="card">
      <div class="image-box">
        <img src="${product.image}" alt="${product.name}" onerror="this.style.display='none'">
      </div>
      <h3>${product.name}</h3>
      <p>${money(product.price)}</p>
      <details class="product-info">
        <summary>Ma'lumotni ko'rish</summary>
        <p>${product.description || 'Bu mahsulot haqida qisqacha ma\'lumot kiritilmagan.'}</p>
      </details>
      <button onclick="addToCart(${product.id})">Savatga qo'shish</button>
    </div>
  `).join('');
}

function addToCart(id) {
  const product = products.find(item => item.id === id);
  let item = cart.find(item => item.id === id);

  if (item) {
    item.quantity++;
  } else {
    cart.push({ ...product, quantity: 1 });
  }

  save();
}

function changeCount(id, count) {
  const item = cart.find(item => item.id === id);
  item.quantity += count;

  if (item.quantity < 1) {
    removeItem(id);
  } else {
    save();
  }
}

function removeItem(id) {
  cart = cart.filter(item => item.id !== id);
  save();
}

function showCart() {
  if (cart.length === 0) {
    $('cart').innerHTML = '<p>Savatcha bo\'sh</p>';
  } else {
    $('cart').innerHTML = cart.map(item => `
      <div class="cart-item">
        <b>${item.name}</b>
        <p>${money(item.price)}</p>
        <div class="cart-buttons">
          <button onclick="changeCount(${item.id}, -1)">-</button>
          <span>${item.quantity}</span>
          <button onclick="changeCount(${item.id}, 1)">+</button>
          <button onclick="removeItem(${item.id})">O'chirish</button>
        </div>
      </div>
    `).join('');
  }

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  $('total').textContent = money(total);
}

function showCardInput() {
  if ($('payment').value === 'Karta orqali') {
    $('card-number').classList.remove('hidden');
  } else {
    $('card-number').classList.add('hidden');
  }
}

async function checkout() {
  if (cart.length === 0) {
    $('status').textContent = 'Savatcha bo\'sh.';
    return;
  }

  if ($('payment').value === 'Karta orqali' && $('card-number').value.trim().length < 16) {
    $('status').textContent = 'Karta raqamini kiriting.';
    return;
  }

  const res = await fetch('/checkout', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: $('name').value,
      phone: $('phone').value,
      payment: $('payment').value,
      cardNumber: $('card-number').value,
      cart: cart
    })
  });

  const order = await res.json();

  if (res.ok) {
    cart = [];
    save();
    $('status').textContent = order.status + '. Buyurtma ID: ' + order.id;
  } else {
    $('status').textContent = order.message;
  }
}

$('payment').addEventListener('change', showCardInput);
showCardInput();
loadProducts();
showCart();
