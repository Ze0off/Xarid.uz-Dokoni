const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;
const dbPath = path.join(__dirname, 'db.json');

app.use(express.json());
app.use(express.static(__dirname));

function readDb() {
  return JSON.parse(fs.readFileSync(dbPath, 'utf-8'));
}

function writeDb(db) {
  fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
}

app.get('/products', (req, res) => {
  const db = readDb();
  res.json(db.products);
});

app.post('/products', (req, res) => {
  const db = readDb();

  const product = {
    id: Date.now(),
    name: req.body.name,
    price: Number(req.body.price),
    image: req.body.image,
    description: req.body.description || ''
  };

  if (!product.name || !product.price || !product.image) {
    return res.status(400).json({ message: 'Barcha maydonlarni to\'ldiring' });
  }

  db.products.push(product);
  writeDb(db);

  res.json(product);
});

app.get('/orders', (req, res) => {
  const db = readDb();
  res.json(db.orders);
});

app.post('/checkout', (req, res) => {
  const db = readDb();
  const cart = req.body.cart || [];

  if (cart.length === 0) {
    return res.status(400).json({ message: 'Savatcha bo\'sh' });
  }

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const order = {
    id: Date.now(),
    name: req.body.name || 'Mehmon',
    phone: req.body.phone || '',
    items: cart,
    total: total,
    payment: req.body.payment || 'Payme',
    cardLast4: req.body.cardNumber ? req.body.cardNumber.slice(-4) : '',
    status: 'Payment Successful'
  };

  db.orders.push(order);
  writeDb(db);

  res.json(order);
});

app.listen(PORT, () => {
  console.log(`Sayt ishladi: http://localhost:${PORT}`);
});
