const $ = id => document.getElementById(id);

function money(price) {
  return price.toLocaleString('uz-UZ') + " so'm";
}

async function addProduct(event) {
  event.preventDefault();

  const product = {
    name: $('product-name').value,
    price: $('product-price').value,
    image: $('product-image').value,
    description: $('product-description').value
  };

  const res = await fetch('/products', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(product)
  });

  const data = await res.json();

  if (res.ok) {
    $('admin-status').textContent = 'Mahsulot qo\'shildi: ' + data.name;
    $('product-form').reset();
    loadAdmin();
  } else {
    $('admin-status').textContent = data.message;
  }
}

async function loadAdmin() {
  const res = await fetch('/products');
  const products = await res.json();

  $('admin-products').innerHTML = products.map(product => `
    <div class="card">
      <div class="image-box">
        <img src="${product.image}" alt="${product.name}" onerror="this.style.display='none'">
      </div>
      <h3>${product.name}</h3>
      <p>${money(product.price)}</p>
      <details class="product-info">
        <summary>Ma'lumotni ko'rish</summary>
        <p>${product.description || 'Ma\'lumot kiritilmagan.'}</p>
      </details>
      <small>${product.image}</small>
    </div>
  `).join('');

  const orderRes = await fetch('/orders');
  const orders = await orderRes.json();

  $('orders').innerHTML = orders.length === 0
    ? '<p>Buyurtma hali yo\'q.</p>'
    : orders.map(order => `
      <div class="order">
        <h3>Buyurtma #${order.id}</h3>
        <p>Mijoz: ${order.name}</p>
        <p>Telefon: ${order.phone}</p>
        <p>Summa: ${money(order.total)}</p>
        <p>To'lov: ${order.payment}</p>
        <p>Karta: ${order.cardLast4 ? '**** ' + order.cardLast4 : 'Kiritilmagan'}</p>
        <p>Status: ${order.status}</p>
      </div>
    `).join('');
}

$('product-form').addEventListener('submit', addProduct);
loadAdmin();
